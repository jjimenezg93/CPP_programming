#include <conio.h>
#include <windows.h>

void gotoxy			(short int x, short int y);
void hidecursor	(void);
void clear			();