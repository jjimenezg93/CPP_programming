/*
Juli�n Jim�nez Gonz�lez
*/

#pragma once

namespace FileUtils {
	unsigned int countString(const unsigned int &fileId, const char * string);

	int addIntegers(const unsigned int &fileId);
}