#pragma once

unsigned int countString(const unsigned int &fileId, const char * string);

int addIntegers(const unsigned int &fileId);